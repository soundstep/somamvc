#!/bin/sh
exec java -jar SomaUI_lin.jar
