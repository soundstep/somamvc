- Go in the SomaUI folder and unzip "SomaUI Linux"
- Open a terminal and login in the administrator account (type su or sudo)
- Go in the folder you have unzipped "/SomaUI Linux/air/bin" and type:
chmod +x ./SomaUI
- Go back in the folder "/SomaUI Linux/" and type:
chmod +x ./SomaUI.sh

Now you should be able to double click on the "SomaUI.sh" script and select "run", SomaUI will launch.

Alternativaly, you can type in the terminal
java -jar SomaUI_lin.jar

Note:
The following output is not an error. This is the messages you should see if you launch the jar file (SomaUI_lin.jar):

0 [main] ERROR merapi.Bridge - ./config/merapi-native-config.xml (No such file or directory)
18 [Thread-0] INFO merapi.Bridge - Merapi started on port: 12345
JAVA > Bridge started