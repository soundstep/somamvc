chmod +x ./SomaUI.sh
to make the file executable

or run in the terminal:
java -jar air/SomaUI_lin.jar
