SomaUI - version BETA 1.0.6
www.soundstep.com

to make SomaUI.sh executable, with an administrator user, type:
chmod +x ./SomaUI.sh

or launch the jar file by typing in a terminal:
java -jar SomaUI_lin.jar
